import React, { useState, useEffect } from 'react';
import { useData } from '../../contexts/DataContext';
import { ShieldCheckIcon, ShieldExclamationIcon, PuzzlePieceIcon, LockClosedIcon, BeakerIcon, HeartIcon } from '@heroicons/react/24/solid';
import loggingService, { LogEntry } from '../../services/loggingService';

const ToggleSwitch: React.FC<{
    label: string;
    description: string;
    enabled: boolean;
    onToggle: (enabled: boolean) => void;
    Icon: React.ElementType;
    iconColor: string;
    disabled?: boolean;
}> = ({ label, description, enabled, onToggle, Icon, iconColor, disabled = false }) => {
    return (
        <div className={`bg-surface-light p-4 rounded-lg border border-border-color flex justify-between items-center ${disabled ? 'opacity-70' : ''}`}>
            <div className="flex items-start">
                <div className={`p-2 rounded-full mr-4 ${enabled ? `${iconColor}/20` : 'bg-gray-500/20'}`}>
                     <Icon className={`h-6 w-6 ${enabled ? iconColor : 'text-gray-500'}`} />
                </div>
                <div>
                    <h3 className="font-bold text-text-primary">{label}</h3>
                    <p className="text-sm text-text-secondary max-w-xl">{description}</p>
                </div>
            </div>
            <label className={`relative inline-flex items-center ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
                <input type="checkbox" checked={enabled} onChange={(e) => !disabled && onToggle(e.target.checked)} className="sr-only peer" disabled={disabled} />
                <div className={`w-14 h-8 bg-gray-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white after:border after:rounded-full after:h-6 after:w-6 after:transition-all ${enabled ? 'peer-checked:bg-secondary' : 'peer-checked:bg-primary'}`}></div>
            </label>
        </div>
    );
};

const ErrorLogViewer: React.FC = () => {
    const [logs, setLogs] = useState<LogEntry[]>([]);

    useEffect(() => {
        setLogs(loggingService.getRecentLogs());
        const interval = setInterval(() => setLogs(loggingService.getRecentLogs()), 2000);
        return () => clearInterval(interval);
    }, []);

    const handleClearLogs = () => {
        loggingService.clearLogs();
        setLogs([]);
    }

    return (
        <div className="bg-surface p-6 rounded-lg border border-border-color">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Simulated Error Log</h2>
                <button onClick={handleClearLogs} className="text-sm btn-secondary px-3 py-1 rounded">Clear Logs</button>
            </div>
            <div className="bg-black font-mono text-xs rounded-lg p-4 h-96 overflow-y-auto">
                {logs.length > 0 ? logs.map(log => (
                    <div key={log.timestamp} className="border-b border-gray-700 pb-2 mb-2">
                        <p className="text-yellow-400">[{log.timestamp}]</p>
                        <p className="text-red-500 font-bold">{log.message}</p>
                        {log.metadata && <p className="text-blue-400">Meta: {JSON.stringify(log.metadata)}</p>}
                        {log.stack && <pre className="text-gray-500 whitespace-pre-wrap">{log.stack}</pre>}
                    </div>
                )) : <p className="text-gray-500">No errors logged in this session.</p>}
            </div>
        </div>
    )
}


const AdminSystemControlsScreen: React.FC = () => {
    const { 
        homePageConfig,
        updateHomePageConfig
    } = useData();
    const [activeTab, setActiveTab] = useState<'Settings' | 'Logs'>('Settings');

    const handleFeatureFlagToggle = (flagName: keyof typeof homePageConfig.featureFlags, enabled: boolean) => {
        const newConfig = {
            ...homePageConfig,
            featureFlags: {
                ...homePageConfig.featureFlags,
                [flagName]: enabled
            }
        };
        updateHomePageConfig(newConfig);
    }


    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-primary">System Controls</h1>
            <p className="text-text-secondary max-w-3xl">Kelola kontrol keamanan, privasi AI, dan fitur eksperimental di seluruh aplikasi.</p>

             <div className="flex border-b border-border-color">
                <button onClick={() => setActiveTab('Settings')} className={`px-4 py-2 font-semibold ${activeTab === 'Settings' ? 'text-primary border-b-2 border-primary' : 'text-text-secondary'}`}>
                    Settings
                </button>
                <button onClick={() => setActiveTab('Logs')} className={`px-4 py-2 font-semibold ${activeTab === 'Logs' ? 'text-primary border-b-2 border-primary' : 'text-text-secondary'}`}>
                    Error Log Viewer
                </button>
            </div>

            {activeTab === 'Settings' ? (
                <div className="space-y-6">
                    <div>
                        <h2 className="text-xl font-bold mb-2">Data Integrity</h2>
                        <div className="bg-surface-light p-4 rounded-lg border border-border-color flex items-center">
                            <div className="p-2 rounded-full mr-4 bg-red-500/20">
                                <LockClosedIcon className="h-6 w-6 text-red-500" />
                            </div>
                            <div>
                                <h3 className="font-bold text-text-primary">Deletion Lock Active (Permanent)</h3>
                                <p className="text-sm text-text-secondary max-w-xl">
                                    Untuk menjaga integritas data dan mencegah penghapusan yang tidak disengaja, semua fungsi penghapusan data inti (produk, artikel, dll.) telah dinonaktifkan secara permanen.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <h2 className="text-xl font-bold mb-2">AI Feature Controls</h2>
                        <div className="space-y-3">
                            <ToggleSwitch
                                label="Enable 'AI Anomaly Detection' Feature"
                                description="Aktifkan pemindaian transaksi oleh AI di Financial Hub untuk mendeteksi aktivitas mencurigakan secara otomatis."
                                enabled={homePageConfig.featureFlags.aiAnomalyDetection}
                                onToggle={(enabled) => handleFeatureFlagToggle('aiAnomalyDetection', enabled)}
                                Icon={ShieldExclamationIcon}
                                iconColor="text-yellow-400"
                            />
                            <ToggleSwitch
                                label="Enable 'AI Symptom Checker' Feature"
                                description="Izinkan pengguna untuk menggunakan asisten AI untuk mendapatkan informasi umum tentang gejala kesehatan (bukan diagnosis medis)."
                                enabled={homePageConfig.featureFlags.aiSymptomChecker}
                                onToggle={(enabled) => handleFeatureFlagToggle('aiSymptomChecker', enabled)}
                                Icon={BeakerIcon}
                                iconColor="text-blue-400"
                            />
                             <ToggleSwitch
                                label="Enable 'Health+ AI Coach' Feature"
                                description="Aktifkan AI coach untuk pelanggan Health+ agar dapat membuat rencana makan dan latihan yang dipersonalisasi."
                                enabled={homePageConfig.featureFlags.aiHealthCoach}
                                onToggle={(enabled) => handleFeatureFlagToggle('aiHealthCoach', enabled)}
                                Icon={HeartIcon}
                                iconColor="text-red-400"
                            />
                        </div>
                    </div>
                     <div>
                        <h2 className="text-xl font-bold mb-2">Experimental Features</h2>
                         <ToggleSwitch
                            label="Enable 'AI Investment Bot' Feature"
                            description="Aktifkan fitur eksperimental 'AI Investment Bot' di menu Akses Cepat pada halaman utama pengguna. Gunakan ini untuk mensimulasikan peluncuran fitur baru yang berisiko."
                            enabled={homePageConfig.featureFlags.aiInvestmentBot}
                            onToggle={(enabled) => handleFeatureFlagToggle('aiInvestmentBot', enabled)}
                            Icon={PuzzlePieceIcon}
                            iconColor="text-purple-400"
                        />
                    </div>
                </div>
            ) : (
                <ErrorLogViewer />
            )}
        </div>
    );
};

export default AdminSystemControlsScreen;